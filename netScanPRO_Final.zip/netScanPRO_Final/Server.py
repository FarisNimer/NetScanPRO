from flask import Flask, request, jsonify, Response
import subprocess

app = Flask(__name__)

sandmap_to_nmap = {
    "tcp_conn": "-sT",
    "udp_scan": "-sU",
    "sctp_scan": "-sY",
    "null_scan": "-sN",
    "fin_scan": "-sF",
    "xmas_scan": "-sX",
    "tcp_ack_scan": "-sA",
    "ssh-run": "--script=ssh-run",
    "ssh-auth-methods": "--script=ssh-auth-methods",
    "sshv1": "--script=sshv1",
    "ssh-hostkey": "--script=ssh-hostkey",
    "telnet-encryption": "--script=telnet-encryption",
    "telnet-ntlm-info": "--script=telnet-ntlm-info",
    "realvnc-auth-bypass": "--script=realvnc-auth-bypass",
    "telnet-brute": "--script=telnet-brute",
    "ssl-cert": "--script=ssl-cert",
    "ssl-enum-ciphers": "--script=ssl-enum-ciphers",
    "ssl-heartbleed": "--script=ssl-heartbleed",
    "ssl-poodle": "--script=ssl-poodle",
    "sslv2-drown": "--script=sslv2-drown",
    "tls-alpn": "--script=tls-alpn",
    "tls-ticketbleed": "--script=tls-ticketbleed",
    "http-apache-server-status": "--script=http-apache-server-status",
    "http-aspnet-debug": "--script=http-aspnet-debug",
    "http-bigip-cookie": "--script=http-bigip-cookie",
    "http-drupal-enum": "--script=http-drupal-enum",
    "http-php-version": "--script=http-php-version",
    "http-robots": "--script=http-robots.txt",
    "http-wordpress-brute": "--script=http-wordpress-brute",
    "os_detection": "-O",
    "os_limit": "-O --osscan-limit",
    "guess_aggressive": "-O --osscan-guess",
    "max_detect": "-O --max-os-tries 1",
    "couchdb-databases": "--script=couchdb-databases",
    "membase-brute": "--script=membase-brute",
    "mongodb-info": "--script=mongodb-info",
    "ms-sql-brute": "--script=ms-sql-brute",
    "mysql-audit": "--script=mysql-audit",
    "mysql-query": "--script=mysql-query",
    "pgsql-brute": "--script=pgsql-brute",
    "http-vuln-cve2006-3392": "--script=http-vuln-cve2006-3392",
    "http-vuln-cve2009-3960": "--script=http-vuln-cve2009-3960",
    "http-vuln-cve2011-3368": "--script=http-vuln-cve2011-3368",
    "http-vuln-cve2013-0156": "--script=http-vuln-cve2013-0156",
    "http-vuln-cve2014-2126": "--script=http-vuln-cve2014-2126",
    "nessus-brute": "--script=nessus-brute",
    "nexpose-brute": "--script=nexpose-brute",
    "omp2-enum-targets": "--script=omp2-enum-targets",
    "openvas-otp-brute": "--script=openvas-otp-brute",
    "shodan-api": "--script=shodan-api",
    "list_scan": "-sL",
    "ping_scan": "-sP",
    "no_port_scan": "-sn",
    "tcp_syn_ping": "-PS",
    "udp_ping": "-PU",
    "icmp_ping-1": "-PE",
}

@app.route("/execute", methods=["POST"])
def execute_scan():
    data = request.get_json()
    option = data.get("option")
    ip_address = data.get("ip_address")

    if not ip_address or not option:
        return jsonify({"error": "IP address and option are required"}), 400

    nmap_flag = sandmap_to_nmap.get(option)
    if not nmap_flag:
        return jsonify({"error": f"Invalid option: {option}"}), 400

    try:
        command = f"nmap {nmap_flag} {ip_address}"
        result = subprocess.run(command.split(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        # Debug output to terminal to ensure Nmap response formatting
        print(f"Nmap Output:\n{result.stdout}")

        if result.returncode == 0:
            # Send as plain text to ensure newlines are preserved
            return Response(result.stdout, mimetype='text/plain')
        else:
            return Response(result.stderr, mimetype='text/plain'), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7681)
