package main

import (
	"fmt"
	"image/color"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
)

type Dashboard struct {
	ipAddress      string
	command        string
	option         string
	dashboardLabel *canvas.Text
}

func NewDashboard() *Dashboard {
	label := canvas.NewText("module:    option:    IP Address:", color.White)
	label.TextStyle = fyne.TextStyle{Bold: true}

	return &Dashboard{
		ipAddress:      "",
		command:        "",
		option:         "",
		dashboardLabel: label,
	}
}

func (d *Dashboard) UpdateDashboard(ip, command, option string) {
	d.ipAddress = ip
	d.command = command
	d.option = option
	d.dashboardLabel.Text = fmt.Sprintf("module: %s    option: %s    IP Address: %s", d.command, d.option, d.ipAddress)
	d.dashboardLabel.Refresh()
}

func (d *Dashboard) BuildUI() *fyne.Container {
	background := canvas.NewRectangle(color.RGBA{64, 64, 64, 255})
	background.SetMinSize(fyne.NewSize(800, 30))

	return container.NewMax(
		background,
		container.NewCenter(d.dashboardLabel),
	)
}
