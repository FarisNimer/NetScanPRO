package main

import (
	"fmt"
	"image/color"
	"strings"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/widget"
)

var (
	outputContainer *fyne.Container
	outputText      string
)

func CreateOutputDisplay() *fyne.Container {
	outputContainer = container.NewVBox()
	scroll := container.NewScroll(outputContainer)
	scroll.SetMinSize(fyne.NewSize(800, 400))

	saveButton := widget.NewButton("Save Output", func() {
		SaveOutputToFile(outputText)
	})

	buttonContainer := container.NewHBox(
		layout.NewSpacer(),
		saveButton,
		layout.NewSpacer(),
	)

	background := canvas.NewRectangle(color.Black)
	background.SetMinSize(fyne.NewSize(800, 400))

	return container.NewVBox(
		container.NewMax(
			background,
			scroll,
		),
		buttonContainer,
	)
}

func UpdateOutput(result string) {
	fmt.Println("Received Nmap Output:")
	fmt.Println(result)

	outputText = result

	// Clear previous content
	outputContainer.Objects = nil

	// Create the main result label
	resultLabel := widget.NewLabel(result)
	resultLabel.TextStyle.Monospace = true
	resultLabel.Wrapping = fyne.TextWrapWord

	// Determine if the scan passed or failed based on "Host is up"
	var statusLabel *canvas.Text
	if strings.Contains(result, "Host is up") {
		statusLabel = canvas.NewText("Result: pass", color.RGBA{0, 255, 0, 255}) // Green for pass
	} else {
		statusLabel = canvas.NewText("Result: fail", color.RGBA{255, 0, 0, 255}) // Red for fail
	}
	statusLabel.TextSize = 16

	// Add both labels to the output container
	outputContainer.Add(resultLabel)
	outputContainer.Add(statusLabel)
	outputContainer.Refresh()
}

// SaveOutputToFile opens a file dialog to save the scan output as a .txt file
func SaveOutputToFile(content string) {
	fileDialog := dialog.NewFileSave(
		func(file fyne.URIWriteCloser, err error) {
			if err != nil || file == nil {
				return
			}
			defer file.Close()

			// Write the content to the selected file
			_, writeErr := file.Write([]byte(content))
			if writeErr != nil {
				dialog.ShowError(writeErr, fyne.CurrentApp().Driver().AllWindows()[0])
			} else {
				dialog.ShowInformation("File Saved", "Output saved successfully.", fyne.CurrentApp().Driver().AllWindows()[0])
			}
		},
		fyne.CurrentApp().Driver().AllWindows()[0], // Main window
	)
	fileDialog.SetFileName("scan_output.txt") // Default file name
	fileDialog.Show()                         // Show the save file dialog
}
