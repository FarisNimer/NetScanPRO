package main

import (
	"encoding/json"
	"fmt"
	"image/color"
	"io/ioutil"
	"os"
	"regexp"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/layout"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"
	"github.com/go-resty/resty/v2"
)

var dashboard *Dashboard
var refreshButton *widget.Button
var users = map[string]string{}
var currentUsername string // Stores the username of the logged-in user

const userDataFile = "users.json"

// Save user data to a file
func saveUserData() {
	data, err := json.Marshal(users)
	if err != nil {
		fmt.Println("Error saving user data:", err)
		return
	}
	err = ioutil.WriteFile(userDataFile, data, 0644)
	if err != nil {
		fmt.Println("Error writing user data to file:", err)
	}
}

// Load user data from a file
func loadUserData() {
	data, err := ioutil.ReadFile(userDataFile)
	if err != nil {
		if os.IsNotExist(err) {
			fmt.Println("User data file does not exist. Creating a new one.")
			return
		}
		fmt.Println("Error reading user data:", err)
		return
	}
	err = json.Unmarshal(data, &users)
	if err != nil {
		fmt.Println("Error parsing user data:", err)
	}
}

// Custom ColoredButton
func NewColoredButton(text string, defaultColor, hoverColor color.Color, tapped func()) *widget.Button {
	button := widget.NewButton(text, tapped)
	button.Importance = widget.HighImportance
	return button
}

// Send command to Flask API
func RunScan(command, option, ipAddress string) string {
	client := resty.New()

	resp, err := client.R().
		SetHeader("Content-Type", "application/json").
		SetBody(map[string]string{
			"command":    command,
			"option":     option,
			"ip_address": ipAddress,
		}).
		Post("http://127.0.0.1:7681/execute")

	if err != nil {
		return "Error contacting Flask server: " + err.Error()
	}

	return resp.String()
}

// Sign-In Page
func CreateSignInPage(myWindow fyne.Window) *fyne.Container {
	usernameEntry := widget.NewEntry()
	usernameEntry.SetPlaceHolder("Enter Username")

	passwordEntry := widget.NewPasswordEntry()
	passwordEntry.SetPlaceHolder("Enter Password")

	signInButton := widget.NewButton("Sign In", func() {
		username := usernameEntry.Text
		password := passwordEntry.Text

		if storedPassword, exists := users[username]; exists {
			if storedPassword == password {
				currentUsername = username // Store the signed-in username
				dialog.ShowInformation("Sign-In Successful", "Welcome back, "+username+"!", myWindow)
				myWindow.SetContent(CreateDashboardPage(myWindow))
			} else {
				dialog.ShowInformation("Sign-In Failed", "Invalid username or password.", myWindow)
			}
		} else {
			dialog.ShowInformation("Account Not Found", "This account does not exist. Please sign up first.", myWindow)
		}
	})

	signUpRedirect := widget.NewButton("Don't have an account? Sign Up", func() {
		myWindow.SetContent(CreateSignUpPage(myWindow))
	})

	// Exit Button
	exitButton := widget.NewButton("Exit", func() {
		myWindow.Close() // Close the window
	})

	return container.NewVBox(
		widget.NewLabelWithStyle("Sign-In Page", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		usernameEntry,
		passwordEntry,
		signInButton,
		signUpRedirect,
		exitButton, // Add Exit button to the Sign-In page
	)
}

// Sign-Up Page
func CreateSignUpPage(myWindow fyne.Window) *fyne.Container {
	usernameEntry := widget.NewEntry()
	usernameEntry.SetPlaceHolder("Enter Username")

	passwordEntry := widget.NewPasswordEntry()
	passwordEntry.SetPlaceHolder("Enter Password")

	emailEntry := widget.NewEntry()
	emailEntry.SetPlaceHolder("Enter Email Address")

	emailRegex := regexp.MustCompile(`^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$`)

	submitButton := widget.NewButton("Sign Up", func() {
		username := usernameEntry.Text
		password := passwordEntry.Text
		email := emailEntry.Text

		if username == "" || password == "" || email == "" {
			dialog.ShowInformation("Sign-Up Failed", "All fields are required!", myWindow)
			return
		}

		if !emailRegex.MatchString(email) {
			dialog.ShowInformation("Invalid Email", "Please enter a valid email address (e.g., example@gmail.com).", myWindow)
			return
		}

		users[username] = password
		saveUserData()
		dialog.ShowInformation("Sign-Up Successful", "Welcome, "+username+"!", myWindow)
		myWindow.SetContent(CreateSignInPage(myWindow))
	})

	// "Back to Sign In" Button
	backToSignInButton := widget.NewButton("Back to Sign In", func() {
		myWindow.SetContent(CreateSignInPage(myWindow)) // Redirects to Sign-In Page
	})

	return container.NewVBox(
		widget.NewLabelWithStyle("Sign-Up Page", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		usernameEntry,
		passwordEntry,
		emailEntry,
		submitButton,
		backToSignInButton, // Add "Back to Sign In" button
	)
}

// Create Profile Icon and Dropdown Menu
func CreateProfileMenu(myWindow fyne.Window) fyne.CanvasObject {
	profileIcon := widget.NewButtonWithIcon("", theme.AccountIcon(), func() {})
	profileMenu := fyne.NewMenu("", // Empty title
		fyne.NewMenuItem(" "+currentUsername, func() {}),
		fyne.NewMenuItemSeparator(),
		fyne.NewMenuItem("Sign Out", func() {
			currentUsername = ""
			myWindow.SetContent(CreateSignInPage(myWindow))
		}),
		fyne.NewMenuItem("Exit", func() { // Add Exit option to user menu
			myWindow.Close() // Close the application window
		}),
	)

	menuPopup := widget.NewPopUpMenu(profileMenu, myWindow.Canvas())

	profileIcon.OnTapped = func() {
		menuPopup.ShowAtPosition(fyne.NewPos(myWindow.Canvas().Size().Width-120, 10))
	}

	return container.NewHBox(layout.NewSpacer(), profileIcon)
}

func CreateDashboardPage(myWindow fyne.Window) *fyne.Container {
	dashboard = NewDashboard()

	commandList := CreateCommandList()
	optionsContainer := CreateOptionsContainer()
	ipInputField := CreateIPInputField()
	outputDisplay := CreateOutputDisplay()
	cliDisplay := CreateCLIDisplay()

	ipInputField.OnChanged = func(ip string) {
		dashboard.UpdateDashboard(ip, dashboard.command, dashboard.option)
	}

	commandList.OnSelected = func(id widget.ListItemID) {
		selectedCommand := commands[id]
		UpdateOptions(selectedCommand)
		dashboard.UpdateDashboard(dashboard.ipAddress, selectedCommand, dashboard.option)
	}

	rightSection := container.NewAppTabs(
		container.NewTabItem("Options", optionsContainer),
		container.NewTabItem("Output", outputDisplay),
		container.NewTabItem("CLI", cliDisplay),
	)

	runScanButton := NewColoredButton("RUN SCAN", color.RGBA{117, 176, 138, 255}, color.RGBA{90, 200, 140, 255}, func() {
		result := RunScan(dashboard.command, dashboard.option, dashboard.ipAddress)
		UpdateOutput(result)
		fmt.Println(result)
		refreshButton.Show()
		rightSection.SelectTabIndex(1)
	})

	refreshButton = widget.NewButtonWithIcon("", theme.ViewRefreshIcon(), func() {
		UpdateOutput("Awaiting new scan results... Click RUN SCAN again to run another scan.")
		refreshButton.Hide()
	})
	refreshButton.Resize(fyne.NewSize(50, 50))
	refreshButton.Hide()

	// Bundled image for logo
	logo := canvas.NewImageFromResource(resourceImgprRemovebgPreviewPng)
	logo.SetMinSize(fyne.NewSize(150, 150))
	logo.FillMode = canvas.ImageFillContain

	commandListContainer := container.NewVScroll(commandList)
	commandListContainer.SetMinSize(fyne.NewSize(200, 400))

	commandBox := widget.NewLabelWithStyle("Modules", fyne.TextAlignCenter, fyne.TextStyle{Bold: true})

	leftPanel := container.NewBorder(
		container.NewVBox(
			commandBox,
			widget.NewSeparator(),
		),
		container.NewVBox(
			widget.NewLabel("Enter Target IP Address:"),
			ipInputField,
		),
		nil,
		nil,
		container.NewVBox(
			commandListContainer,
			container.NewCenter(logo),
		),
	)

	infoBox := dashboard.BuildUI()
	bottomBar := container.NewBorder(
		nil, nil, nil,
		runScanButton,
		container.NewCenter(infoBox),
	)
	mainLayout := container.NewHSplit(leftPanel, rightSection)
	mainLayout.SetOffset(0.25)
	toolbar := CreateProfileMenu(myWindow)
	content := container.NewBorder(toolbar, bottomBar, nil, nil, mainLayout)
	return content

}

func main() {
	myApp := app.New()
	myApp.Settings().SetTheme(theme.DarkTheme())

	iconData, err := os.ReadFile("icon.ico")
	if err != nil {
		fmt.Println("Error loading icon:", err)
	} else {
		appIcon := fyne.NewStaticResource("icon.ico", iconData)
		myApp.SetIcon(appIcon)
	}

	myWindow := myApp.NewWindow("NetScan PRO")
	myWindow.SetFullScreen(false)

	// Load user data when the app starts
	loadUserData()

	// Bundled image for home logo
	logo := canvas.NewImageFromResource(resourceImagePng)
	logo.SetMinSize(fyne.NewSize(200, 200))
	logo.FillMode = canvas.ImageFillContain

	signInButton := widget.NewButton("Sign In", func() {
		myWindow.SetContent(CreateSignInPage(myWindow))
	})
	signUpButton := widget.NewButton("Sign Up", func() {
		myWindow.SetContent(CreateSignUpPage(myWindow))
	})

	exitButton := widget.NewButton("Exit", func() {
		myApp.Quit() // Quits the application safely
	})

	homeLayout := container.NewVBox(
		widget.NewLabelWithStyle("Welcome to NetScan PRO", fyne.TextAlignCenter, fyne.TextStyle{Bold: true}),
		container.NewCenter(logo),
		signInButton,
		signUpButton,
		exitButton, // Add Exit button to the home screen layout
	)

	myWindow.SetContent(homeLayout)
	myWindow.CenterOnScreen()
	myWindow.ShowAndRun()
}

func UpdateDashboardWithOption(selectedOption string) {
	dashboard.UpdateDashboard(dashboard.ipAddress, dashboard.command, selectedOption)
	if desc, found := optionDescriptions[selectedOption]; found {
		descriptionLabel.SetText(desc)
	} else {
		descriptionLabel.SetText("Description not available.")
	}
	UpdateInfoBox()
}

func UpdateInfoBox() {
	dashboard.BuildUI()
}
