package main

import (
	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/widget"
)

var commands = []string{
	"port_scan", "nse_remote-access", "nse_ssl", "nse_Http-Services",
	"os_detection", "nse_databases", "nse_http-cve", "nse_vuln-scanners",
	"host_discovery",
}

func CreateCommandList() *widget.List {
	return widget.NewList(
		func() int { return len(commands) },
		func() fyne.CanvasObject { return widget.NewLabel("") },
		func(i widget.ListItemID, o fyne.CanvasObject) {
			o.(*widget.Label).SetText(commands[i])

		},
	)
}
