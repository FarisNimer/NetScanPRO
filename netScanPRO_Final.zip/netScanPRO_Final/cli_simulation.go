package main

import (
	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/widget"
	webview "github.com/webview/webview_go"
)

func CreateCLIDisplay() *fyne.Container {
	// Message displayed in the application
	initialText := "Welcome to the WebView interface!\n" +
		"Click the button below to open a web page.\n"

	output := widget.NewLabel(initialText)
	output.Wrapping = fyne.TextWrapWord

	// Button to open the WebView
	button := widget.NewButton("Click Here", func() {
		go func() {
			// Open a webview with a predefined URL
			w := webview.New(true)
			defer w.Destroy()
			w.SetTitle("WebView Browser")
			w.SetSize(800, 600, webview.HintNone)
			w.Navigate("http://localhost:4041/") // URL to be opened
			w.Run()
		}()

	})

	// Create a vertical layout with the output label and button
	content := container.NewVBox(
		output,
		button,
	)

	return content
}
