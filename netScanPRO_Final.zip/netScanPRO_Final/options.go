package main

import (
	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/widget"
)

var optionContainer *fyne.Container
var descriptionLabel *widget.Label

var optionDescriptions = map[string]string{
	"tcp_conn":                  "Performs a TCP connect scan by initiating a full TCP connection to each port being scanned.\nThis is the most basic form of TCP scanning and is relatively stealthy as it completes the fullthree-way handshake.",
	"udp_scan":                  "Initiates a UDP scan, which is used to determine which UDP (User Datagram Protocol) ports are open.\nUDP scanning is more challenging than TCP scanning since UDP does not use a handshake mechanism.\nIt sends empty UDP packets to the target ports and waits for responses.",
	"sctp_scan":                 "Conducts an SCTP scan, which is used to determine which SCTP (Stream Control Transmission Protocol) ports are open.\nSCTP scanning is similar to TCP scanning but targets SCTP ports.",
	"null_scan":                 "Executes a NULL scan, where no flags are set during TCP connection establishment.\nThis technique relies on the fact that some systems, if a TCP port is closed, will respond with a RST packet, while others will not respond at all.",
	"fin_scan":                  "Performs a FIN scan, where the FIN flag is set during TCP connection establishment.\nIt relies on the fact that some systems, if a TCP port is closed, will respond with a RST packet, while others will ignore the packet altogether.",
	"xmas_scan":                 "Initiates an Xmas scan, where the FIN, URG, and PUSH flags are set during TCP connection establishment.\nThis scan is used to detect listening ports on the target system.",
	"tcp_ack_scan":              "Conducts a TCP ACK scan, where only the ACK flag is set during TCP connection establishment.\nIt's primarily used to map out firewall rule sets, determining whether they're stateful or not.",
	"ssh-run":                   "Executes a custom SSH command specified by the user, facilitating remote administration and management tasks.",
	"ssh-auth-methods":          "Enumerates authentication methods supported by SSH (Secure Shell), providing insights into security configurations.",
	"sshv1":                     "Checks for support of SSH version 1 (SSHv1), which is known to have security vulnerabilities and should be avoided.",
	"ssh-hostkey":               "Retrieves and checks the SSH host key, helping to verify the authenticity of the SSH server.",
	"telnet-encryption":         "Checks for encryption support in Telnet sessions, which enhances security by protecting data in transit.",
	"telnet-ntlm-info":          "Retrieves NTLM information from Telnet servers, providing insights into the authentication mechanism used.",
	"realvnc-auth-bypass":       "Detects RealVNC servers vulnerable to authentication bypass, potentially allowing unauthorized access to the system.",
	"telnet-brute":              "Performs brute-force attacks against Telnet login, attempting to identify weak passwords and gain unauthorized access.",
	"rsa-vuln-roca":             "Checks for the ROCA (Return of Coppersmith's Attack) vulnerability in RSA keys, which could lead to cryptographic weaknesses.",
	"ssl-cert":                  "Retrieves and displays SSL certificate information, including issuer, subject, and validity dates.",
	"ssl-enum-ciphers":          "Enumerates supported SSL/TLS ciphers and protocols, providing insights into cryptographic configurations.",
	"ssl-heartbleed":            "Checks for the Heartbleed vulnerability in SSL/TLS implementations, which could lead to the exposure of sensitive information.",
	"ssl-poodle":                "Checks for the POODLE (Padding Oracle On Downgraded Legacy Encryption) vulnerability in SSLv3, which could lead to data leakage.",
	"sslv2-drown":               "Checks for the DROWN (Decrypting RSA with Obsolete and Weakened eNcryption) vulnerability in SSLv2, which could lead to decryption of secure communications.",
	"tls-alpn":                  "Checks for Application-Layer Protocol Negotiation (ALPN) support in TLS servers, providing insights into protocol support.",
	"tls-ticketbleed":           "Checks for the Ticketbleed vulnerability in OpenSSL, which could lead to information leakage from SSL/TLS sessions.",
	"http-apache-server-status": "Retrieves server status from Apache HTTP servers with mod_status enabled, providing activity and uptime data.",
	"http-aspnet-debug":         "Checks for ASP.NET debug mode, potentially exposing sensitive information about the web application.",
	"http-bigip-cookie":         "Checks for the presence of a BIG-IP load balancer cookie, indicating the use of F5 BIG-IP devices.",
	"http-drupal-enum":          "Enumerates Drupal installations, providing information about modules, themes, and more for vulnerability assessment.",
	"http-php-version":          "Detects the version of PHP running on a web server, providing insights into potential vulnerabilities.",
	"http-robots":               "Retrieves the robots.txt file from a web server, revealing directives for web crawlers and access permissions.",
	"http-wordpress-brute":      "Performs brute-force attacks against WordPress login pages to identify weak passwords.",
	"os_detection":              "Enables OS detection during the scan.\nThis option instructs Nmap to attempt to determine the operating system running on the target hosts based on various signatures.",
	"os_limit":                  "Limits OS detection to promising targets only.\nThis option tells Nmap to perform OS detection only on hosts that respond to initial probes, potentially saving time.",
	"guess_aggressive":          "Enables aggressive OS detection, increasing the likelihood of accurate OS identification but also potentially increasing the chance of false positives.",
	"max_detect":                "Sets the maximum number of OS detection tries to 1, ensuring that Nmap performs OS detection only once per target host.",
	"couchdb-databases":         "Executes a script to enumerate CouchDB databases.\nCouchDB is a NoSQL database that stores data in JSON documents, and this script helps in discovering available databases for further analysis.",
	"membase-brute":             "Executes a script to perform brute force attacks against Membase, a distributed key-value store.\nThis script attempts to guess passwords for authentication and can be used for security assessment purposes.",
	"mongodb-info":              "Initiates a script to gather general information about MongoDB.\nThis can include details about the MongoDB instance, its configuration, version, and other relevant information.",
	"ms-sql-brute":              "Conducts a script to perform brute force attacks against Microsoft SQL Server instances.\nThis script attempts to guess passwords for authentication and can be used for security assessment purposes.",
	"mysql-audit":               "Initiates a script to perform security audits on MySQL servers.\nThis can include checks for common security issues, misconfigurations, or vulnerabilities present in MySQL deployments.",
	"mysql-query":               "Conducts a script to execute custom SQL queries against MySQL servers.\nThis can be used for querying specific data or performing custom assessments against MySQL databases.",
	"pgsql-brute":               "Initiates a script to perform brute force attacks",
	"http-vuln-cve2006-3392":    "Executes an NSE script to detect vulnerabilities in HTTP services associated\nwith the CVE-2006-3392 identifier, potentially indicating buffer overflow or code execution flaws.",
	"http-vuln-cve2009-3960":    "Targets vulnerabilities in HTTP services identified under CVE-2009-3960, potentially\nindicating security flaws such as remote code execution or denial of service (DoS) vulnerabilities.",
	"http-vuln-cve2011-3368":    "Executes an NSE script designed to identify vulnerabilities in HTTP services associated with the CVE-2011-3368 identifier.",
	"http-vuln-cve2013-0156":    "Targets vulnerabilities in HTTP services identified under CVE-2013-0156, likely indicating security issues such as cross-site scripting (XSS) or authentication bypass.",
	"http-vuln-cve2014-2126":    "Identifies vulnerabilities in HTTP services documented under CVE-2014-2126, potentially indicating security flaws like SQL injection or remote code execution.",
	"nessus-brute":              "Executes an NSE script to perform brute-force attacks against Nessus vulnerability scanners, attempting to guess login credentials for unauthorized access.",
	"nexpose-brute":             "Focuses on performing brute-force attacks against Nexpose vulnerability scanners, attempting to guess login credentials for unauthorized access.",
	"omp2-enum-targets":         "Targets OpenVAS vulnerability scanners and enumerates potential targets for further assessment or exploitation, aiding in reconnaissance during\nsecurity assessments.",
	"openvas-otp-brute":         "Performs brute-force attacks against OpenVAS vulnerability scanners, targeting One-Time Password (OTP) authentication mechanisms to gain unauthorized access.",
	"shodan-api":                "Utilizes the Shodan API to gather information about hosts, services, and vulnerabilities, allowing users to conduct reconnaissance and security assessments.",
	"list_scan":                 "Performs a list scan, which simply lists each target host without sending any packets to them.",
	"ping_scan":                 "Conducts a ping scan, sending ICMP echo requests to determine which hosts are up and responsive.",
	"no_port_scan":              "Skips the port scan phase and only performs host discovery, useful for quickly determining live hosts.",
	"tcp_syn_ping":              "Sends TCP SYN packets to probe for live hosts, commonly used in environments where ICMP is blocked.",
	"udp_ping":                  "Sends UDP packets to probe for live hosts, useful for detecting hosts that respond to UDP traffic.",
	"icmp_ping-1":               "Performs an ICMP echo request ping scan, also known as an ICMP type 8 or 'ping' scan.",
}

var options = []string{}

func CreateOptionsContainer() *fyne.Container {
	descriptionLabel = widget.NewLabel("Description of the selected command will appear here.")
	optionContainer = container.NewVBox()

	return container.NewVBox(
		optionContainer,
		descriptionLabel,
	)
}

func UpdateOptions(command string) {
	switch command {
	case "port_scan":
		options = []string{"tcp_conn", "udp_scan", "sctp_scan", "null_scan", "fin_scan", "xmas_scan", "tcp_ack_scan"}
		descriptionLabel.SetText("Description: Scans specified IP addresses or subnets for open ports. It helps identify available services running on a machine.\nPurpose: Port scanning is essential in vulnerability assessment and determining which services are accessible.")
	case "os_detection":
		options = []string{"os_detection", "os_limit", "guess_aggressive", "max_detect"}
		descriptionLabel.SetText("Description: Detects the operating system (OS) of the target machine.\nPurpose: Identifies the OS fingerprint to tailor further tests based on the OS type (Linux, Windows, macOS).")
	case "host_discovery":
		options = []string{"list_scan", "ping_scan", "no_port_scan", "tcp_syn_ping", "udp_ping", "icmp_ping-1"}
		descriptionLabel.SetText("Description: Identifies active hosts in a given network range.\nPurpose: Determines live systems in a subnet or range for reconnaissance.")
	case "nse_databases":
		options = []string{"couchdb-databases", "membase-brute", "mongodb-info", "ms-sql-brute", "mysql-audit", "mysql-query", "pgsql-brute"}
		descriptionLabel.SetText("Description: Focuses on discovering and testing databases like MySQL, MSSQL, and PostgreSQL.\nPurpose: Identifies accessible databases, misconfigurations, and weak credentials.")
	case "nse_ssl":
		options = []string{"rsa-vuln-roca", "ssl-cert", "ssl-enum-ciphers", "ssl-heartbleed", "ssl-poodle", "sslv2-drown", "tls-alpn", "tls-ticketbleed"}
		descriptionLabel.SetText("Description: Performs SSL/TLS-related scans to test the strength and configuration of SSL encryption.\nPurpose: Identifies weak ciphers, expired certificates, and misconfigurations in SSL implementations.")
	case "nse_remote-access":
		options = []string{"ssh-run", "ssh-auth-methods", "sshv1", "ssh-hostkey", "telnet-encryption", "telnet-ntlm-info", "realvnc-auth-bypass", "telnet-brute"}
		descriptionLabel.SetText("Description: Focuses on identifying and testing remote access services such as SSH, RDP, and VNC.\nPurpose: Useful for determining potential entry points via remote services.")
	case "nse_Http-Services":
		options = []string{"http-apache-server-status", "http-aspnet-debug", "http-bigip-cookie", "http-drupal-enum", "http-php-version", "http-robots", "http-wordpress-brute"}
		descriptionLabel.SetText("Description: Scans web servers for information and vulnerabilities.\nPurpose: Useful for mapping web services and identifying potentially vulnerable web applications.")
	case "nse_http-cve":
		options = []string{"http-vuln-cve2006-3392", "http-vuln-cve2009-3960", "http-vuln-cve2011-3368", "http-vuln-cve2013-0156", "http-vuln-cve2014-2126"}
		descriptionLabel.SetText("Description: Scans web servers for Common Vulnerabilities and Exposures (CVEs).\nPurpose: Detects whether known CVEs apply to a web service, ensuring proactive security.")
	case "nse_vuln-scanners":
		options = []string{"nessus-brute", "nexpose-brute", "omp2-enum-targets", "openvas-otp-brute", "shodan-api"}
		descriptionLabel.SetText("Description: General category for scripts that look for various vulnerabilities.\nPurpose: A broad category for detecting known vulnerabilities and weaknesses.")
	default:
		options = []string{"No options available"}
		descriptionLabel.SetText("")
	}

	optionContainer.Objects = nil
	for _, opt := range options {
		optionButton := widget.NewButton(opt, func(o string) func() {
			return func() {
				UpdateDashboardWithOption(o)

				if desc, found := optionDescriptions[o]; found {
					descriptionLabel.SetText(desc)
				} else {
					descriptionLabel.SetText("Description not available.")
				}
			}
		}(opt))
		optionContainer.Add(optionButton)
	}

	optionContainer.Refresh()
}

func CreateIPInputField() *widget.Entry {
	ipInput := widget.NewEntry()
	ipInput.SetPlaceHolder("Enter Target IP Address")
	return ipInput
}
